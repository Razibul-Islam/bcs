import React from 'react';

const Pakage = () => {
    return (
        <div>
            this is pakage page
        </div>
    );
};

export default Pakage;