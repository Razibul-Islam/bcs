import { initializeApp } from "firebase/app";
import {getAuth} from "firebase/auth"





const firebaseConfig = {
    apiKey: "AIzaSyC69rAbI5N1M0rvmeY_RIMCb34FV78HUZc",
    authDomain: "bcspioneer.firebaseapp.com",
    projectId: "bcspioneer",
    storageBucket: "bcspioneer.appspot.com",
    messagingSenderId: "151124891862",
    appId: "1:151124891862:web:30f16e637c4fb1339fd177"
};


const app = initializeApp(firebaseConfig);


const auth = getAuth(app);


export default auth;