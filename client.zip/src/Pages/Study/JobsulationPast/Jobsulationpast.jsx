import React from 'react';

const Jobsulationpast = () => {

  

  return (
    <div>
      <h1 className='my-5 text-center'>বিগত জব সলিউশন প্রশ্ন</h1>
    </div>
  );
};

export default Jobsulationpast;